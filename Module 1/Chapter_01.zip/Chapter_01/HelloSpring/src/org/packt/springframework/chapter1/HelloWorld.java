package org.packt.springframework.chapter1;

public class HelloWorld {

	private String message;

	public String getMessage() {
		return this.message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
