package org.packt.Spring.chapter2.loosecouple;

/**
 * 
 * @author RaviKantSoni
 * 
 */
public interface EmployeeService {

	public Long generateEployeeID();

}
