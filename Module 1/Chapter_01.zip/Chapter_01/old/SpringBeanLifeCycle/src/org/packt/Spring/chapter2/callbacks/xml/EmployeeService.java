package org.packt.Spring.chapter2.callbacks.xml;

/**
 * 
 * @author RaviKantSoni
 * 
 */
public interface EmployeeService {

	public Long generateEployeeID();

}
