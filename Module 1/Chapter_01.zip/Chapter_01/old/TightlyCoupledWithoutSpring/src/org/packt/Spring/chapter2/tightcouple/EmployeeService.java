package org.packt.Spring.chapter2.tightcouple;

/**
 * 
 * @author RaviKantSoni
 * 
 */
public interface EmployeeService {

	public Long generateEployeeID();

}
