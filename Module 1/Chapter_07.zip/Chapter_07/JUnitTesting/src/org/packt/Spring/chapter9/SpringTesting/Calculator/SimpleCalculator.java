package org.packt.Spring.chapter9.SpringTesting.Calculator;

public interface SimpleCalculator {

	public long add(int a, int b);

}
