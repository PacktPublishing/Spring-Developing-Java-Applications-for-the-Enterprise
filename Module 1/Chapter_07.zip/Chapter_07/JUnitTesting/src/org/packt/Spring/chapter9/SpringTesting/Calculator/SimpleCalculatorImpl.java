package org.packt.Spring.chapter9.SpringTesting.Calculator;

public class SimpleCalculatorImpl implements SimpleCalculator {

	public long add(int a, int b) {
		return a + b;
	}
}
