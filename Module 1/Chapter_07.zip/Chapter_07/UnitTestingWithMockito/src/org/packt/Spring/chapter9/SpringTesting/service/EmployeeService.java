package org.packt.Spring.chapter9.SpringTesting.service;

import org.packt.Spring.chapter9.SpringTesting.modle.Employee;

public interface EmployeeService {

	public Employee findEmployee(String employeeId);

}
