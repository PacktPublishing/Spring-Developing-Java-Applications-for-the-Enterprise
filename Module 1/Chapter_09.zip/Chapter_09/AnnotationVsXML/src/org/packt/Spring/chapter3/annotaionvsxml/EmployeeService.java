package org.packt.Spring.chapter3.annotaionvsxml;

public interface EmployeeService {

}
