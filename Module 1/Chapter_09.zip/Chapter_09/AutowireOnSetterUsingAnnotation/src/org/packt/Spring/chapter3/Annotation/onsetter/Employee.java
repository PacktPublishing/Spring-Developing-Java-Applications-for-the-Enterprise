package org.packt.Spring.chapter3.Annotation.onsetter;

public class Employee {

	@Override
	public String toString() {
		return "From employee class";
	}

}
