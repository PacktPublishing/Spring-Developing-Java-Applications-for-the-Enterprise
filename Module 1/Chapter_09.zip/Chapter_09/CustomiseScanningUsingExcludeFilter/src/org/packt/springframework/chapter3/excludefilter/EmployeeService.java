package org.packt.springframework.chapter3.excludefilter;

public interface EmployeeService {

}
