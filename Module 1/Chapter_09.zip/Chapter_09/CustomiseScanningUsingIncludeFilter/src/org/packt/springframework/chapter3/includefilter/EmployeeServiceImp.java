package org.packt.springframework.chapter3.includefilter;

public class EmployeeServiceImp implements EmployeeService {

	public String toString() {
		return "Implements business logic in Service class";
	}

}
