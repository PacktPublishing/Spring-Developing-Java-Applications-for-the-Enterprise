package org.packt.Spring.chapter3.Annotation.fasle;

public class Address {

	@Override
	public String toString() {
		return "From to address";
	}

}
