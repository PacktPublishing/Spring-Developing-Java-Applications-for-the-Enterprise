package org.packt.springframework.chapter3.includefilter;

public class EmployeeDAO {

	public String toString() {
		return "Implements data access logic in DAO class";
	}

}
