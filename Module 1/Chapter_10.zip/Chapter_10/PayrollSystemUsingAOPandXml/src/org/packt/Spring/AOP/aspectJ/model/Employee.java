package org.packt.Spring.AOP.aspectJ.model;

public class Employee {

	private String empName;

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}
}
