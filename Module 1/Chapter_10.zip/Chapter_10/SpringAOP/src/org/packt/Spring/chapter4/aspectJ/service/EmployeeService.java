package org.packt.Spring.chapter4.aspectJ.service;

import org.packt.Spring.chapter4.aspectJ.model.Employee;

public class EmployeeService {

	private Employee employee;

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

}
