package com.packt.webstore.service;

public interface ProductService {

	void updateAllStock();
}
